
from playsound import playsound
playsound("amy.mp3")
