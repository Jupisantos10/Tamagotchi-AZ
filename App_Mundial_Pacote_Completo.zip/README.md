# App Mundial

Projeto completo com fala e avatar Amy.